- uLED Repaired:
    - 因為這案子的佈署涉及許多不確定性溝通 + 我們 Team 經驗較少，因此我先把 PM 工作接下
    - 請 Regina 整體想一下目前演算法運行的時候顧慮點
( **原說周三，** **改 ****週二 ****課周報先出一些顧慮清單** )，我後續理解後轉成週四、週五可以討論的內容
-  uLED Wafer IQC 系統:
    - 我明天上午跟 Rex 對一下現況後，跟約時間奕宏對
Multi- plot
- uLED Wafer IQC 演算法:
    - 新數據 Re-training 機制討論要不要先做
- uLED QC/MMS :
    - 這部分 PM 我再找 Rex 談
- ChatGPT in AUO:
    - Azure Search 確定另外申請，走
DB 的話可能還自己想權限管理議題 ( Gorge 認知上 file 目前比較好管權限)，但先不管，我們先申請
    - ChatGPT 跟 Search Engine 部分，我們要落實之前周五題的 ( 我再跟妙珊、林璟談)
    - HR: 我跟 Joany 聊完後再確認 PM，Joany 先跟今天一樣想一下有沒有一些疑惑點還沒被解答
    - MI: 收斂 & 第一步測試內容討論( 我再跟妙珊、林璟談)
- MI:
    - 保持數據進資料庫，因為現況有很多資源分配權衡，目前 MI 所有需求請先讓我知道，被要求東西就說
Eric 要先同意，請他們問我
